--공연 날짜,시간 테이블
select*from content;
select*from contentTime;


insert into contentTime 
values(1,to_date('20230709','yyyy-mm-dd'),'17:00');

insert into contentTime 
values(2,to_date('20230623','yyyy-mm-dd'),'19:30');
insert into contentTime 
values(2,to_date('20230624','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(2,to_date('20230624','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(2,to_date('20230625','yyyy-mm-dd'),'17:00');
insert into contentTime 
values(2,to_date('20230630','yyyy-mm-dd'),'19:30');
insert into contentTime 
values(2,to_date('20230701','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(2,to_date('20230701','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(2,to_date('20230702','yyyy-mm-dd'),'17:00');

insert into contentTime 
values(3,to_date('20230610','yyyy-mm-dd'),'17:00');

insert into contentTime 
values(4,to_date('20230609','yyyy-mm-dd'),'20:00');

insert into contentTime 
values(5,to_date('20230617','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(5,to_date('20230618','yyyy-mm-dd'),'20:00');

insert into contentTime 
values(6,to_date('20230611','yyyy-mm-dd'),'19:00');
insert into contentTime 
values(6,to_date('20230612','yyyy-mm-dd'),'19:00');



insert into contentTime 
values(7,to_date('20230701','yyyy-mm-dd'),'19:00');
insert into contentTime 
values(7,to_date('20230702','yyyy-mm-dd'),'19:00');

insert into contentTime 
values(8,to_date('20230605','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(8,to_date('20230606','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(8,to_date('20230607','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(8,to_date('20230608','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(8,to_date('20230609','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(8,to_date('20230610','yyyy-mm-dd'),'15:00');
insert into contentTime 
values(8,to_date('20230610','yyyy-mm-dd'),'19:00');
insert into contentTime 
values(8,to_date('20230611','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(8,to_date('20230611','yyyy-mm-dd'),'18:00');

insert into contentTime 
values(9,to_date('20230611','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(9,to_date('20230611','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(9,to_date('20230613','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(9,to_date('20230614','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(9,to_date('20230615','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(9,to_date('20230616','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(9,to_date('20230617','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(9,to_date('20230617','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(9,to_date('20230618','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(9,to_date('20230618','yyyy-mm-dd'),'18:00');

insert into contentTime 
values(10,to_date('20230523','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(10,to_date('20230524','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(10,to_date('20230525','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(10,to_date('20230526','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(10,to_date('20230527','yyyy-mm-dd'),'15:00');
insert into contentTime 
values(10,to_date('20230527','yyyy-mm-dd'),'19:00');
insert into contentTime 
values(10,to_date('20230528','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(10,to_date('20230528','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(10,to_date('20230530','yyyy-mm-dd'),'20:00');
insert into contentTime 
values(10,to_date('20230531','yyyy-mm-dd'),'20:00');

insert into contentTime 
values(11,to_date('20230527','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(11,to_date('20230528','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(11,to_date('20230606','yyyy-mm-dd'),'17:00');
insert into contentTime 
values(11,to_date('20230607','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(11,to_date('20230608','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(11,to_date('20230609','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(11,to_date('20230610','yyyy-mm-dd'),'17:00');
insert into contentTime 
values(11,to_date('20230611','yyyy-mm-dd'),'17:00');

insert into contentTime 
values(12,to_date('20230527','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(12,to_date('20230528','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(12,to_date('20230606','yyyy-mm-dd'),'17:00');
insert into contentTime 
values(12,to_date('20230607','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(12,to_date('20230608','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(12,to_date('20230609','yyyy-mm-dd'),'18:30');

insert into contentTime 
values(13,to_date('20230527','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(13,to_date('20230528','yyyy-mm-dd'),'14:00');
insert into contentTime 
values(13,to_date('20230606','yyyy-mm-dd'),'17:00');
insert into contentTime 
values(13,to_date('20230607','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(13,to_date('20230608','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(13,to_date('20230609','yyyy-mm-dd'),'18:30');
insert into contentTime 
values(13,to_date('20230610','yyyy-mm-dd'),'17:00');
insert into contentTime 
values(13,to_date('20230611','yyyy-mm-dd'),'17:00');

insert into contentTime 
values(14,to_date('20230521','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(14,to_date('20230524','yyyy-mm-dd'),'19:00');
insert into contentTime 
values(14,to_date('20230603','yyyy-mm-dd'),'18:00');
insert into contentTime 
values(14,to_date('20230611','yyyy-mm-dd'),'19:00');
insert into contentTime 
values(14,to_date('20230624','yyyy-mm-dd'),'16:30');

insert into contentTime 
values(15,to_date('20230526','yyyy-mm-dd'),'11:30');
insert into contentTime 
values(15,to_date('20230527','yyyy-mm-dd'),'11:30');
insert into contentTime 
values(15,to_date('20230528','yyyy-mm-dd'),'11:30');

insert into contentTime 
values(16,to_date('20230603','yyyy-mm-dd'),'13:00');
insert into contentTime 
values(16,to_date('20230604','yyyy-mm-dd'),'13:00');

insert into contentTime 
values(17,to_date('20230906','yyyy-mm-dd'),'상시상품');
insert into contentTime 
values(18,to_date('20230815','yyyy-mm-dd'),'상시상품');


