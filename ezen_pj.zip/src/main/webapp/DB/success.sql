

select * from SUCCESS_BOARD;


insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 3, 'gangji', '1234',
'임영웅 전국투어-서울 성공내역1',
'임영웅 전국투어 - 서울 대리티켓팅 이용 감사 드립니다. 다음에 또 이용 시 보다 좋은 좌석과 서비스로 보답 드리겠습니다. 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 3, 'gangji', '1234',
'임영웅 전국투어-서울 성공내역2',
'임영웅 전국투어 - 서울 대리티켓팅 이용 감사 드립니다. 다음에 또 이용 시 보다 좋은 좌석과 서비스로 보답 드리겠습니다. 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 3, 'gangji', '1234',
'임영웅 전국투어-서울 성공내역3',
'임영웅 전국투어 - 서울 대리티켓팅 이용 감사 드립니다. 다음에 또 이용 시 보다 좋은 좌석과 서비스로 보답 드리겠습니다. 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 3, 'gangji', '1234',
'임영웅 전국투어-서울 성공내역4',
'임영웅 전국투어 - 서울 대리티켓팅 이용 감사 드립니다. 다음에 또 이용 시 보다 좋은 좌석과 서비스로 보답 드리겠습니다. 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 3, 'gangji', '1234',
'임영웅 전국투어-서울 성공내역5',
'임영웅 전국투어 - 서울 대리티켓팅 이용 감사 드립니다. 다음에 또 이용 시 보다 좋은 좌석과 서비스로 보답 드리겠습니다. 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 3, 'gangji', '1234',
'임영웅 전국투어-서울 성공내역6',
'임영웅 전국투어 - 서울 대리티켓팅 이용 감사 드립니다. 다음에 또 이용 시 보다 좋은 좌석과 서비스로 보답 드리겠습니다. 감사합니다.');


insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 4, 'jrong', '1234',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역1',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역입니다! 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 4, 'jrong', '1234',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역2',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역입니다! 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 4, 'jrong', '1234',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역3',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역입니다! 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 4, 'jrong', '1234',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역4',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역입니다! 감사합니다.');
insert into success_board(sucseq, mseq, id,pwd, title, content) 
values(success_board_sucseq.nextVal, 4, 'jrong', '1234',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역5',
'티켓온 팬텀싱어(광주) 대리티켓팅 성공내역입니다! 감사합니다.');












